create table test_table (
    id int not null auto_increment,
    first_name varchar(60),
    last_name varchar(60),
    address varchar(60),
    phone_number varchar(60),
    PRIMARY KEY (id)
);